<?php echo e($slot); ?>

<?php /**PATH W:\Projects_Laravel\eMail Laravel\resources\views/vendor/mail/text/panel.blade.php ENDPATH**/ ?>