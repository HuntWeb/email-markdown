
Introduction 
Hello <?php echo e($recipient); ?>


The body of your message. <?php echo e($mail_content); ?>




Thanks,<br>


<?php /**PATH W:\Projects_Laravel\project-setup\resources\views/emails/WelcomeMail.blade.php ENDPATH**/ ?>