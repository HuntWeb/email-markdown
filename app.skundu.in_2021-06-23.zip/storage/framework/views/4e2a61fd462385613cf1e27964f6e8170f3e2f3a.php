[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH W:\Projects_Laravel\eMail Laravel\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>