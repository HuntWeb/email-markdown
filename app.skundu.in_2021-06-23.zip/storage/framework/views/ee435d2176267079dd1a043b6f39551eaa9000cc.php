<?php echo e($slot); ?>

<?php /**PATH W:\Projects_Laravel\eMail Laravel\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>