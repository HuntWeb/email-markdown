


<a href="<?php echo e($url); ?>" target="_blank" class="button button-new"><?php echo e($slot); ?></a>
<a href="<?php echo e($url); ?>" target="_blank" class="button button-blue"><?php echo e($slot); ?></a><?php /**PATH W:\Projects_Laravel\project-setup\resources\views/vendor/mail/html/button.blade.php ENDPATH**/ ?>