<?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

<?php /**PATH W:\Projects_Laravel\eMail Laravel\resources\views/vendor/mail/html/footer.blade.php ENDPATH**/ ?>