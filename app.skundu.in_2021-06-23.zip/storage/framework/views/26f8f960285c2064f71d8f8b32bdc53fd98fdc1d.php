<?php echo e($slot); ?>

<?php /**PATH W:\Projects_Laravel\project-setup\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>