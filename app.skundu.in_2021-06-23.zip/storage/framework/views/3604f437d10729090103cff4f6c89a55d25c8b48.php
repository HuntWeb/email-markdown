<?php echo e($slot); ?>

<?php /**PATH W:\Projects_Laravel\eMail Laravel\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>