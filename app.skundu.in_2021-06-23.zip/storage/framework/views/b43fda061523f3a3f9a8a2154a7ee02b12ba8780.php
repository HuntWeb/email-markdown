<?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

<?php /**PATH W:\Projects_Laravel\project-setup\resources\views/vendor/mail/html/footer.blade.php ENDPATH**/ ?>